The 404-server (defaultbackend) has moved to the
[kubernetes/ingress-gce](https://github.com/kubernetes/ingress-gce) repository.
