# Deprecated

Please switch to [debian-base](https://github.com/kubernetes/kubernetes/tree/master/build/debian-base)
